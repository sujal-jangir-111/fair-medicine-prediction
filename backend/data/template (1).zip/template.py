import cv2
import numpy as np


# Helper functions

def resize_image(image, new_height=500):
    # Calculate the ratio of the old height to the new height
    ratio = image.shape[0] / float(new_height)
    
    # Calculate the new width to keep the aspect ratio the same
    new_width = int(image.shape[1] * (new_height / float(image.shape[0])))
    
    # Resize the image using OpenCV
    resized = cv2.resize(image, (new_width, new_height))
    
    return resized, ratio


def get_document_corners(edged_img):
    # Find the contours (outlines) of the edged image
    contours, _ = cv2.findContours(edged_img.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    # Sort the contours by area(largest first) and keep top 5
    contours = [c for c in contours if cv2.contourArea(c) > 10000]
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:5]

    # Loop over the top 5 contours
    for c in contours:
        # Calculate the perimeter of the contour
        peri = cv2.arcLength(c, True)
        
        # Approximate the shape of the contour to a polygon
        # Try multiple tolerance levels to catch slightly rounded or noisy page edges.
        for eps in [0.015, 0.02, 0.03, 0.04]:
            approx = cv2.approxPolyDP(c, eps * peri, True)
            
            # if our approximated contour has exactly 4 points, we can assume it's the paper!
            if len(approx) == 4:
                return approx
        
    # FallBack: If no strict 4-point polygon found, use the largest countour's box
    h, w = edged_img.shape[:2]
    return np.array([[[0, 0]], [[w-1, 0]], [[w-1, h-1]], [[0, h-1]]], dtype=np.int32)

def prepare_warp_data(corners: np.ndarray) -> tuple[np.ndarray, np.ndarray, int, int]:
    """
    Calculates the dimensions and destination points for the student's warp task.
    (Instructor Code)
    """
    # Order the points: Top-Left, Top-Right, Bottom-Right, Bottom-Left
    pts = corners.reshape(4, 2)
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    
    (tl, tr, br, bl) = rect

    # Calculate the max width and max height
    widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    maxWidth = max(int(widthA), int(widthB))

    heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    maxHeight = max(int(heightA), int(heightB))

    # Create the destination points for a flat rectangle
    dst = np.array([
        [0, 0],
        [maxWidth - 1, 0],
        [maxWidth - 1, maxHeight - 1],
        [0, maxHeight - 1]], dtype="float32")

    return rect, dst, maxWidth, maxHeight




# Image Preprocessing
def process_image(path: str) -> tuple[np.ndarray, np.ndarray]:
    """
    Task 1: Read the image and convert to grayscale.

    Parameters:
    - path: The file path of the input image.

    TODO
    1. Read the image.
    2. Convert the image to grayscale.
    3. Return the original image and the grayscale image.
    """

    pass
  
# Blurring and edge detection.
def blur_and_edge_detection(gray_img: np.ndarray) -> np.ndarray:
    """
    Task 2: Apply Gaussian blur to a grayscale image and then find its edge.

    Parameters:
    - gray_img: The grayscale image to be preprocessed.

    TODO
    1. Apply a Gaussian Blur to the image.
    2. Apply Canny Edge Detection to the blurred image.
    3. Return the final image with edges detected.
    """

    pass

# perspective transform
def perspective_transform(img: np.ndarray, src_pts: np.ndarray, dst_pts: np.ndarray, width: int, height: int) -> np.ndarray:
    """
    Applies a perspective transformation to flatten the document.
    
    Parameters:
    - img (np.ndarray): The original color image.
    - src_pts (np.ndarray): The 4 corners of the paper in the original image.
    - dst_pts (np.ndarray): The 4 corners of a perfect flat rectangle.
    - width (int): The calculated width of the new flattened image.
    - height (int): The calculated height of the new flattened image.
    
    TODO:
    1. Get the perspective transform matrix.
    2. Warp the image.
    3. Return the warped image.

    """
    
    pass

# Thresholding
def apply_threshold(warped_img: np.ndarray) -> np.ndarray:
    """
    Applies thresholding to give the document a clean, black-and-white scanned look.
    
    Parameters:
    - warped_img (np.ndarray): The flattened, cropped color image of the document.
    
    TODO:
    1. Convert the 'warped_img' to grayscale.
    2. Apply cv2.threshold() to the grayscale image. 
    3. Return the final thresholded image.

    """
    
    pass