import cv2
import os
from PIL import Image, JpegImagePlugin
from template import *

# 1. Create Folder
inputFolder = "input_images"

if not os.path.exists(inputFolder):
    os.makedirs(inputFolder)
    
    print("Created 'input_images' folder...")
    print("Please put .jpeg or .png in input_images...\n")

# Wait for user to put all the images in the folder.
input("Press ENTER after you have added all the images...")

# Make a list all all image files.
imageFiles = [ fileName
               for fileName in os.listdir(inputFolder)
               if fileName.lower().endswith((".jpeg", ".png", ".jpg"))
             ]

# If inputFolder is empty then stop the program.
if not imageFiles:
    print("\nNo image found in input_images folder...")
    print("Please put the .jpeg / .png images in the folder and run the program again!")
    exit()

print(f"\nFound {len(imageFiles)} image(s).\n")

# 2. List for scanned pages
scanned_pages = []

# 3. Process every image

for fileName in imageFiles:
    imagePath = os.path.join(inputFolder, fileName)
    
    print((f"Processing: {fileName}"))
    
    # RGB --> Gray
    originalImage, grayImage = process_image(imagePath)
    
    # Resize gray scale image
    resizedGray, ratio = resize_image(grayImage)
    
    # Blur and detect edges
    edges = blur_and_edge_detection(resizedGray)
    
    # Document Corners
    corners = get_document_corners(edges)
    
    # Error Check
    if corners is None:
        print(f"No Document detected in {fileName}. Skipping...\n")
        continue
    
    # Scale corners back to original image size
    corners = (corners.reshape(4,2)*ratio).astype("float32")
    
    # Prepare perspective warp data
    rect, dst, width, height = prepare_warp_data(corners)
    
    # Perspective Transformation
    warpedImages = perspective_transform(originalImage, rect, dst, width, height)
    
    # Apply black and white threshold
    finalImage = apply_threshold(warpedImages)
    
    # Convert openCV grayscale to RGB
    rgbImage = cv2.cvtColor(finalImage, cv2.COLOR_GRAY2RGB)
    
    # Convert OpenCV image to PIL image
    pilImage = Image.fromarray(rgbImage)
    
    # Add the finished page to the list.
    scanned_pages.append(pilImage)
    
    print(f"Finished: {fileName}\n")

# Check weather images are scanned or not.
if not scanned_pages:
    print("No pages were successfully scanned.")
    print("PDF was not created.")

else:
    # Creating the PDF of final output images.
    outputPdf = "Final_Scanned_Document.pdf"
    scanned_pages[0].save(outputPdf, save_all = True, append_images = scanned_pages[1:])
    
    print("=============================")
    print("PDF Created Successfully!")
    print(f"FILE: {outputPdf}")
    print("=============================")
